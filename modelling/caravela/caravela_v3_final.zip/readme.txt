Title:
Caravela Ibérica de Três Mastros

Modeling and texturing:
Luís F. Loureiro 

Twitter:
@nczeroshift

License:
http://creativecommons.org/licenses/by/4.0/

5 of August 2014